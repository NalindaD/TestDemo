<?php
include("userValidationClass.php");


$userClass = new UserClass();

$errorMessage = "" ;

if (!empty($_POST['submitloginform'])) {
	
	$username=$_POST['username'];
    $password=$_POST['userpassowrd'];

	if(strlen(trim($username))>1 && strlen(trim($password))>1 ){
		$uid=$userClass->userLogin($username,$password);
        if($uid){
 		
 			$url='../index.php';
            header("Location: $url"); // Page redirecting to home.php 
 		
			
		
		}
		else{
			$errorMessage = "Please enter the valid credential" ;
		}
	}
	else{
		$errorMessage = "Please Enter the valid details" ;
		
	}
}	
?>




<!DOCTYPE html>
<html>
<head>
	<title></title>
      <script src="../jquery.min.js"></script>


	<style type="text/css">


@import url('https://fonts.googleapis.com/css?family=Montserrat:200,300,400,500,600,700');



		body{   
      color: #333;
      font-size: 14px;
      font-weight: 400;  
		 font-family: 'Montserrat', sans-serif;

			background: url('../images/destination-2.jpg');
			background-size: cover;
			padding: 0;
			margin: 0;
			position: relative;
		}



		.sec{
			height: 100vh;
			width: 400px; 
			background: rgba(255,255,255,.7);
			position: absolute;
			right: 0;
			overflow: auto;
			box-shadow: -10px 0px 10px 1px rgba(0,0,0,.2)
		}
		.sec-con{
			margin: 50px;
		}
		.sec-con h2{
			position: absolute;
			right: 0;top: 0px;
		}
		.sec-con img{
			border-radius: 50%;
			background: #fff;
			width: 100px;
			margin: 0 auto;
			margin-bottom: 20px;
		}
		.img-sec{
			text-align: center;
			margin-top: 110px;
		}
		.sec-con a{
			color: #fff;
			text-decoration: none;
		}
		input{
			padding: 12px 20px;
			margin: 0px 0 5px 0;display: inline-block;;
			border:1px solid #ccc;
			width: 100%;
			border-radius: 4px;
			box-sizing: border-box;
		}
		h1{
			color: #fff;
			margin: 50px;
			position: absolute;
			left: 0;
			text-shadow: -2px 2px 2px rgba(0,0,0,.8);
		}
		h1 span{color: #1f98ed;}
		ul{
			position: absolute;right: 0;
			top: 0;
		}
		li{
			list-style: none;
			display: inline-block;
			padding: 10px;
			background: #000;
			color: #fff;
		}
		.active{
			list-style: none;
			display: inline-block;
			padding: 10px;
			background: #666;
			color: #fff;
		}



.pulse-animation {
  width: 100px;
  border-radius: 50%;
  background: #ff8717;
  cursor: pointer;  
  animation: pulse 2s infinite;
}
.pulse-animation:hover {
  animation: none;
}

@keyframes pulse {
  0% {
    -moz-box-shadow: 0 0 0 0 rgba(31,152,237, 0.4);
    box-shadow: 0 0 0 0 rgba(31,152,237, 0.4);
  }
  70% {
      -moz-box-shadow: 0 0 0 30px rgba(31,152,237, 0);
      box-shadow: 0 0 0 30px rgba(31,152,237, 0);
  }
  100% {
      -moz-box-shadow: 0 0 0 0 rgba(31,152,237, 0);
      box-shadow: 0 0 0 0 rgba(31,152,237, 0);
  }
}

	</style>

<style>
/* Paste this css to your style sheet file or under head tag */
/* This only works with JavaScript, 
if it's not present, don't show loader */
.no-js #loader { display: none;  }
.js #loader { display: block; position: absolute; left: 100px; top: 0; }
.se-pre-con {
  position: fixed;
  left: 0px;
  top: 0px;
  width: 100%;
  height: 100%;
  z-index: 9999;
  background: url('../images/ajax-loader.gif') center no-repeat #fff;
}
</style>
<script>
  $(window).load(function() {
    setTimeout(function(){
    $(".se-pre-con").fadeOut("slow");
    },500)
  });
</script>



</head>
<body>
<div class="se-pre-con"></div>
	<a href="../index.php"><h1>Tec<span>site</span></h1></a>
<div class ="sec">
	<div class="sec-con">
	<ul>
		<li class="active"><a href="login.php">SIGN IN</a></li>
		<li><a href="Register.php">SIGN UP</a></li>
	</ul>
		<div class="img-sec"><img class="pulse-animation" src="../user.png"></div>



	<form  method="post" action="" name="login">
	<div class="login-html">

<div class="errorMsg"><?php echo $errorMessage; ?></div>

		<div class="login-form">
			<div class="sign-in-htm">
				<div class="group">
					<label  class="label">Username</label>
					<input type="text" name="username" id="username" class="input"  autocomplete="off" />
				</div>
				<div class="group">
					<label for="pass" class="label">Password</label>
					<input type="password" name="userpassowrd" class="input" autocomplete="off"/>
				</div>
				<div class="group">
					<label for="check"><input type="check" name=""> <span class="icon"></span> Keep me Signed in</label>
				</div>
				<div class="group">
					<input type="submit" class="button" name="submitloginform" value="Login">
				</div>
				<div class="hr"></div>
			</div>
		</div>
	</div>
</form>




	</div>
</div>
</body>
</html>





