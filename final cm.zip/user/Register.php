

<?php
require_once('../includes/config.php');	
include("userValidationClass.php");

	$check = new UserClass;
	$check_login = $check->logged_in();


$userClass = new UserClass();

$errorMessage = "" ;
$sucessMessage = "" ;
if (!empty($_POST['submitregistrationform'])) {
	
$username=$_POST['username'];
$email=$_POST['emailid'];
$user_type=$_POST['user_type'];
$password=$_POST['userpassowrd'];
$nic=$_POST['nic'];
$address=$_POST['address'];
$mobile_no=$_POST['mobile_no'];

//$date= date();
/* Regular expression check */
$username_check = preg_match('~^[A-Za-z0-9_]{3,20}$~i', $username);
$email_check = preg_match('~^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.([a-zA-Z]{2,4})$~i', $email);
//$password_check = preg_match('~^[A-Za-z0-9!@#$%^&*()_]{6,20}$~i', $password);

if($username_check && $email_check  ){
	
     $uid=$userClass->userRegistration($username,$email,$user_type,$password,$nic,$address,$mobile_no);
	
	if($uid){
		
	  $sucessMessage = "Registration successful, Please
	  "."<a href='login.php'>Login</a>" ;
	 
	}
	else{
		$errorMessage = "Email already exists";
	}
	
	
}
else{
	$errorMessage = "Please enter the valid details";
} 
	
}

?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">


@import url('https://fonts.googleapis.com/css?family=Montserrat:200,300,400,500,600,700');



		body{   
      color: #333;
      font-size: 14px;
      font-weight: 400;  
		 font-family: 'Montserrat', sans-serif;

			background: url('../images/destination-1.jpg');
			background-size: cover;
			padding: 0;
			margin: 0;
			position: relative;
		}



		.sec{
			height: 100vh;
			width: 400px; 
			background: rgba(255,255,255,.7);
			position: absolute;
			right: 0;
			overflow: auto;
			box-shadow: -10px 0px 10px 1px rgba(0,0,0,.2)
		}
		.sec-con{
			margin: 50px;
		}
		.sec-con h2{
			position: absolute;
			right: 0;top: 0px;
		}
		.sec-con img{
			border-radius: 50%;
			background: #fff;
			width: 100px;
			margin: 0 auto;
		}
		.img-sec{
			text-align: center;
			margin-top: 110px;
		}
		.sec-con a{
			color: #fff;
			text-decoration: none;
		}
		input{
			padding: 12px 20px;
			margin: 0px 0 5px 0;display: inline-block;;
			border:1px solid #ccc;
			width: 100%;
			border-radius: 4px;
			box-sizing: border-box;
		}
		h1{
			color: #fff;
			margin: 50px;
			position: absolute;
			left: 0;
			text-shadow: -2px 2px 2px rgba(0,0,0,.8);
		}
		h1 span{color: #1f98ed;}
		ul{
			position: absolute;right: 0;
			top: 0;
		}
		li{
			list-style: none;
			display: inline-block;
			padding: 10px;
			background: #000;
			color: #fff;
		}
		.active{
			list-style: none;
			display: inline-block;
			padding: 10px;
			background: #666;
			color: #fff;
		}



.pulse-animation {
  width: 100px;
  border-radius: 50%;
  background: #ff8717;
  cursor: pointer;  
  animation: pulse 2s infinite;
}
.pulse-animation:hover {
  animation: none;
}

@keyframes pulse {
  0% {
    -moz-box-shadow: 0 0 0 0 rgba(31,152,237, 0.4);
    box-shadow: 0 0 0 0 rgba(31,152,237, 0.4);
  }
  70% {
      -moz-box-shadow: 0 0 0 30px rgba(31,152,237, 0);
      box-shadow: 0 0 0 30px rgba(31,152,237, 0);
  }
  100% {
      -moz-box-shadow: 0 0 0 0 rgba(31,152,237, 0);
      box-shadow: 0 0 0 0 rgba(31,152,237, 0);
  }
}

	</style>

 <script src="../jquery.min.js"></script>
 <script>  
$(document).ready(function() { 
  $('.error_Msg').hide(); 
  $('.error_mobile').hide();  
  $('.error_nic').hide(); 
  $('.submit').click(function(event){ 
    var data=$('#mobile_no').val(); 
     if(phone_validate(data)) 
     { 
       $('.error_Msg').hide();  // hides error msg if validation is true
     } 
     else 
     { 
       $('.error_Msg').show();   // shows validation msg if validation is false
       event.preventDefault(); 
     }  
     if($('#mobile_no').val().length==10) 
     { 
       $('.error_mobile').hide();  // hides error msg if validation is true
     } 
     else 
     { 
       $('.error_mobile').show();   // shows validation msg if validation is false
       event.preventDefault(); 
     } 



     if($('#nic').val().length==13 || $('#nic').val().length==10) 
     { 
       $('.error_nic').hide();  // hides error msg if validation is true
     } 
     else 
     { 
       $('.error_nic').show();   // shows validation msg if validation is false
       event.preventDefault(); 
     } 




    }); 
 }); 
   
   function phone_validate(phno) 
{ 
  var regexPattern=new RegExp(/^[0-9-+]+$/);    // regular expression pattern
  return regexPattern.test(phno); 
} 
 </script>

 <style>
   
    .error_Msg,.error_mobile,.error_nic,.errorMsg{ color:#fa4b2a; padding-left: 10px; border-radius: 3px; border:1px solid #fa4b2a;} 
    .sucessMsg{ color:#00ed00; padding-left: 10px; border-radius: 3px; border:1px solid #00ed00;} 
   body{font-family:Verdana;}
 </style>

  <style>
    #contact label{
      display: inline-block;
      width: 100px;
      text-align: right;
    }
    #contact_submit{
      padding-left: 100px;
    }
    #contact div{
      margin-top: 1em;
    }
    textarea{
      vertical-align: top;
      height: 5em;
    }
      
    .error{
      display: none;
      margin-left: 10px;
    }   
    
    .error_show{
      color: red;
      margin-left: 10px;
    }
    
    input.invalid:focus, textarea.invalid:focus{
      border: 2px solid red;
    }
    
    input.valid, textarea.valid{
      border: 2px solid green;
    }   
    input.valid:focus, textarea.valid:focus{
      border: 2px solid green;
    }
  </style>



  <script>
    $(document).ready(function() {
      <!-- Real-time Validation -->
        <!--Name cant be blank -->

        <!--Email must be an email -->
        $('#email').on('input', function() {
          var input=$(this);
          var re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
          var is_email=re.test(input.val());
          if(is_email){input.removeClass("invalid").addClass("valid");}
          else{input.removeClass("valid").addClass("invalid");}
        });
        
      
      
    });
  </script>
<style>
/* Paste this css to your style sheet file or under head tag */
/* This only works with JavaScript, 
if it's not present, don't show loader */
.no-js #loader { display: none;  }
.js #loader { display: block; position: absolute; left: 100px; top: 0; }
.se-pre-con {
  position: fixed;
  left: 0px;
  top: 0px;
  width: 100%;
  height: 100%;
  z-index: 9999;
  background: url('../images/ajax-loader.gif') center no-repeat #fff;
}
</style>
<script>
  $(window).load(function() {
    setTimeout(function(){
    $(".se-pre-con").fadeOut("slow");
    },500)
  });
</script>


</head>
<body>


<div class="se-pre-con"></div>

  <a href="../index.php"><h1>Tec<span>site</span></h1></a>
<div class ="sec">
	<div class="sec-con">
	<ul>


    <li><a href="login.php">SIGN IN</a></li>
    <li class="active"><a href="Register.php">SIGN UP</a></li>

	</ul>
		<div class="img-sec"><img class="pulse-animation" src="../user.png"></div>

<!-- 
----------------------------------------------------------------------------------- -->





<div class="errorMsg danger"><?php echo $errorMessage; ?></div>
<div class="sucessMsg success"><?php echo $sucessMessage; ?></div>


<form method="post" action="" name="register">

<label>Name</label>
<input type="text" name="username" class="form-control" />
<label>Email</label>
<input type="text" name="emailid" id="email" class="form-control" autocomplete="off" />
    <?php if($check_login == true && $_SESSION['user_type']=="admin"){ ?>
<label>user_type</label>
<select name="user_type" class="form-control" >

  <option value="admin">Admin</option>
  <option value="user">User</option>

    <?php }else{ ?>

</select>
    <?php }
    ?>
    <br>
<label>Password</label>
<input type="password" name="userpassowrd" class="form-control" autocomplete="off"/>



<label>nic</label>
<input type="text" name="nic" id="nic" class="form-control" autocomplete="off" />

<label>address</label>
<input type="text" name="address" class="form-control" autocomplete="off" />

<label>mobile_no</label>
<input type="text"  class="phone_val form-control" name="mobile_no" id="mobile_no" />



<p class="error_nic">  Error! NIC can contain only 10 or 13  
</p> 

<p class="error_Msg"> Error! Phone number can contain only numbers from 0-9 
</p> 
<p class="error_mobile">  Error! Phone number can contain only 10 numbers 
</p> 


<hr><input class="submit" type="submit" name="submitregistrationform" value="Register">
</form>



<!-- -----------------------------------------------------------------------------------	 -->
	</div>
</div>
</body>
</html>