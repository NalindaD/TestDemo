
<?php
session_start(); 
	$_SESSION['loggedin'] = false;
	$_SESSION['id']=''; 
	$_SESSION['user_type']=''; 
session_unset(); 

$url='login.php';
header("Location: $url"); // Page redirecting to login.php 
 
?>

