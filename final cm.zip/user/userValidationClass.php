<?php


Class UserClass{

// connect to mysql database	
public function DBConnect(){

$dbhost ="localhost"; // set the hostname
$dbname ="hndit" ; // set the database name
$dbuser ="root" ; // set the mysql username
$dbpass ="";  // set the mysql password

try {
$dbConnection = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass); 
$dbConnection->exec("set names utf8");
$dbConnection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
return $dbConnection;

}
catch (PDOException $e) {
echo 'Connection failed: ' . $e->getMessage();
}
	
	
	
}




// logic and validation
public function userRegistration($username,$email,$user_type,$password,$nic,$address,$mobile_no){

try{
$dbConnection = $this->DBConnect();
$stmt = $dbConnection->prepare('SELECT * FROM `user` WHERE `email` = :email ');
$stmt->bindParam(":email", $email,PDO::PARAM_STR);
$stmt->execute();

$Count = $stmt->rowCount();
if($Count < 1){
// insert the new record when match not found...
$stmt = $dbConnection->prepare('INSERT INTO `user`(username,email,user_type,password,nic,address,mobile_no) 
VALUES(:username,:email,:user_type,:password,:nic,:address,:mobile_no)');
$joindate =  date("F j, Y, g:i a"); 
$hash_password= hash('sha256', $password); //password encryption
$stmt->bindParam(':username', $username,PDO::PARAM_STR ); 
$stmt->bindParam(':email', $email,PDO::PARAM_STR); 
$stmt->bindParam(':user_type', $user_type,PDO::PARAM_STR); 
$stmt->bindParam(':password', $hash_password,PDO::PARAM_STR ); 

$stmt->bindParam(':nic', $nic,PDO::PARAM_STR );
$stmt->bindParam(':address', $address,PDO::PARAM_STR );
$stmt->bindParam(':mobile_no', $mobile_no,PDO::PARAM_STR );
$stmt->execute();

$Count = $stmt->rowCount();

if($Count  == 1 )	{
$uid=$dbConnection->lastInsertId(); // Last inserted row id
$dbConnection = null;

return true;  

}
else{
$dbConnection = null;
return false;	
}
	



}else{
	//echo "Email-ID already exits";
$dbConnection = null;
return false;	
}
}
catch (PDOException $e) {
echo 'Connection failed: ' . $e->getMessage();
}
	
}	
	
// logic and validation for user login page
public function userLogin($username,$password){
	
	try{
		$dbConnection = $this->DBConnect();
        $stmt = $dbConnection->prepare('SELECT * FROM `user` 
		WHERE `username` = :username and `password` = :password');
		$hash_password= hash('sha256', $password); 
		$stmt->bindParam(":username", $username,PDO::PARAM_STR);
		$stmt->bindParam(":password", $hash_password,PDO::PARAM_STR);
		$stmt->execute();

		$Count = $stmt->rowCount();
		$data=$stmt->fetch(PDO::FETCH_OBJ);
		if($Count == 1){
			session_start();

			$_SESSION['loggedin'] = true;
			$_SESSION['id']=$data->id; 
			$_SESSION['user_type']=$data->user_type; 
			$dbConnection = null ;
            return true;
						
		}
		else{
			$dbConnection = null ;
            return false ;
			
		}
		
	}
	catch (PDOException $e) {
		echo 'Connection failed: ' . $e->getMessage();
	}
	
}




//////	



	public function logged_in(){
			 return (isset($_SESSION['loggedin'])) ? true : false;
	}

	// public function get_all_posts(){
	// 	$pdo = $this->DBConnect();
	// 	$query = $pdo->prepare('SELECT * FROM user order by uid desc');
	// 	$query->execute();

	// 	return $query->fetchAll(PDO::FETCH_ASSOC);
	// }

	
}



////////////////////////////




?>