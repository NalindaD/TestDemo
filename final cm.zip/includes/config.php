<?php
session_start();
try {
    $db = new PDO('mysql:host=localhost;dbname=hndit', 'root', '');
} catch (PDOException $e) {
    print "Connetion Error!: " . $e->getMessage() . "<br/>";
    die();
}
?>