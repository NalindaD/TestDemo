<?php 
include("user/userValidationClass.php");
include ("includes/config.php");
  $check = new UserClass;
  $check_login = $check->logged_in();


 ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>test</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container">
        <a class="navbar-brand" href="index.html">Tech<span>best solution</span></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active"><a href="index.html" class="nav-link">Home</a></li>
            <li class="nav-item"><a href="about.html" class="nav-link">About</a></li>
            <li class="nav-item"><a href="destination.html" class="nav-link">Services</a></li>
            <li class="nav-item"><a href="blog.html" class="nav-link">Activities</a></li>
            <li class="nav-item"><a href="contact.html" class="nav-link">Contact</a></li>
            
<?php if($check_login == false){ ?>
          <li class="nav-item  cta" style="margin-right: 2px;"><a class="nav-link" href="user/login.php">Sign In</a></li>
          <li class="nav-item  cta"><a class="nav-link" href="user/Registration.php">Sign Up</a></li>
<?php }else{ ?>
          <li class="nav-item  cta"><a class="nav-link" href="user/logout.php">Sign Out</a></li>
<?php } ?>

          </ul>
        </div>
      </div>
    </nav>
    <!-- END nav -->
    
    <div class="hero-wrap js-fullheight" style="background-image: url('images/-bg_2.jpg');" data-stellar-background-ratio="0.5" >
 
      <div class="overlay" style="background-image: url('images/bg.gif') ;opacity: .1 ; background-repeat: no-repeat; background-size: cover;"></div>

      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-center" data-scrollax-parent="true">
          <div class="col-md-9 text text-center ftco-animate" data-scrollax=" properties: { translateY: '70%' }">
            <a href="https://vimeo.com/45830194" class="icon-video popup-vimeo d-flex align-items-center justify-content-center mb-4">
              <span class="ion-ios-play"></span>
            </a>
            <p class="caps" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Travel to the any corner of the world, without going around in circles <br>sssss<?php echo $_SESSION['id']; ?></p>
            <h1 data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Make Your  Amazing With Us</h1>




          </div>
        </div>
      </div>
    </div>

    <section class="ftco-section ftco-no-pb ftco-no-pt">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="search-wrap-1 ftco-animate p-4">
              <form action="#" class="search-property-1">
                <div class="row">
                  <div class="col-lg align-items-end">
                    <div class="form-group">
                      <label for="#"></label>
                      <input type="text" name="">
                    </div>
                  </div>
                  <div class="col-lg align-items-end">
                  </div>
                  <div class="col-lg align-items-end">
                  </div>
                  <div class="col-lg align-items-end">
                  </div>
                  <div class="col-lg align-self-end">
                    <div class="form-group">
                      <div class="form-field">
                        <input type="submit" value="Search" class="form-control btn btn-primary">
                      </div>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section services-section bg-light">
      <div class="container">
        <div class="row d-flex">
          <div class="col-md-12">
            <div class="row">
                <div class="row" style="width: 100%;">
                    <div class="heading-m col-md-12">

          <div class="col-md-12 heading-section text-center ftco-animate">
            <h2 class="mb-4">Our Services</h2>
          </div>

                    </div>
                </div>
                <div class="col-md-4 d-flex align-self-stretch ftco-animate" >
                    <div class="media block-6 services d-block box-service">
                      <div class="icon">
                        <img src="images/sw.png">
                      </div>
                      <div class="media-body">
                        <h3 class="heading mb-3">Software Development</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor</p>
                      </div>
                    </div>      
                  </div>
                  <div class="col-md-4 d-flex align-self-stretch ftco-animate">
                    <div class="media block-6 services d-block box-service">
                      <div class="icon">
                        <img src="images/and.png">
                      </div>
                      <div class="media-body">
                        <h3 class="heading mb-3">Android Development</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor</p>
                      </div>
                    </div>    
                  </div>
                  <div class="col-md-4 d-flex align-self-stretch ftco-animate">
                    <div class="media block-6 services d-block box-service">
                      <div class="icon">
                        <img src="images/web.jpg">
                      </div>
                      <div class="media-body">
                        <h3 class="heading mb-3">Web Designing and Development</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor</p>
                      </div>
                    </div>      
                  </div>
            </div>
          </div>





          
          <div class="col-md-12">
            <div class="row">
                <div class="row" style="width: 100%;">
                </div>
                <div class="col-md-4 d-flex align-self-stretch ftco-animate">
                    <div class="media block-6 services d-block box-service">
                      <div class="icon">
                        <img src="images/led.jpg">
                      </div>
                      <div class="media-body">
                        <h3 class="heading mb-3">Light Boad</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor</p>
                        <a class="btn btn-primary" href="">See More </a>
                      </div>
                    </div>      
                  </div>
                  <div class="col-md-4 d-flex align-self-stretch ftco-animate">
                    <div class="media block-6 services d-block box-service">
                      <div class="icon"></div>
                      <div class="media-body">
                        <h3 class="heading mb-3">test</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor</p>
                      </div>
                    </div>    
                  </div>
                  <div class="col-md-4 d-flex align-self-stretch ftco-animate">
                    <div class="media block-6 services d-block box-service">
                      <div class="icon"><span class="flaticon--guide"></span></div>
                      <div class="media-body">
                        <h3 class="heading mb-3">test</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor</p>
                      </div>
                    </div>      
                  </div>
            </div>
          </div>




        </div>
      </div>
    </section>

    <section class="ftco-counter img" id="section-counter">
      <div class="container">
        <div class="row d-flex">
          <div class="col-md-6 d-flex">
            <div class="img d-flex align-self-stretch" style="background-image:url(images/img.jpg);"></div>
          </div>
          <div class="col-md-6 pl-md-5 py-5">
            <div class="row justify-content-start pb-3">
              <div class="col-md-12 heading-section ftco-animate">
                <h2 class="mb-4">OUR CLIENTS</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                    consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                    cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                    proident, sunt in culpa qui officia deserunt mollit anim id est laborum.  .</p>
              </div>
            </div>
            <div class="row">
                  <div class="col-md-4 justify-content-center counter-wrap ftco-animate">
                    
                  </div>
                  <div class="col-md-4 justify-content-center counter-wrap ftco-animate">
                    <div class="block-18 text-center mb-4">
                      <div class="text">
                        <strong class="number" data-number="300">0</strong>
                        <span>Our Clients</span>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4 justify-content-center counter-wrap ftco-animate">
                    
                  </div>

  
            </div>
          </div>
        </div>
      </div>
    </section>


    
    <section class="ftco-section ftco-no-pt">
      <div class="container">
        <div class="row justify-content-center pb-4">
          <div class="col-md-12 heading-section text-center ftco-animate">
            <h2 class="mb-4">Our Works</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4 ftco-animate">
            <div class="project-wrap">
              <a href="#" class="img" style="background-image: url(images/destination-1.jpg);"></a>
              <div class="text p-4">
                <span class="price">Rs. 30,000</span>
                <span class="days">8 Days </span>
                <h3><a href="#">company, one</a></h3>
                <p class="location"><span class="ion-ios-map"></span> company, one</p>
              </div>
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="project-wrap">
              <a href="#" class="img" style="background-image: url(images/destination-2.jpg);"></a>
              <div class="text p-4">
                <span class="price">Rs. 30,000</span>
                <span class="days">10 Days </span>
                <h3><a href="#">company, one</a></h3>
                <p class="location"><span class="ion-ios-map"></span> company, one</p>
              </div>
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="project-wrap">
              <a href="#" class="img" style="background-image: url(images/destination-3.jpg);"></a>
              <div class="text p-4">
                <span class="price">Rs. 30,000</span>
                <span class="days">7 Days </span>
                <h3><a href="#">company, one</a></h3>
                <p class="location"><span class="ion-ios-map"></span> company, one</p>
              </div>
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="project-wrap">
              <a href="#" class="img" style="background-image: url(images/destination-1.jpg);"></a>
              <div class="text p-4">
                <span class="price">Rs. 30,000</span>
                <span class="days">8 Days </span>
                <h3><a href="#">company, one</a></h3>
                <p class="location"><span class="ion-ios-map"></span> company, one</p>
              </div>
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="project-wrap">
              <a href="#" class="img" style="background-image: url(images/destination-3.jpg);"></a>
              <div class="text p-4">
                <span class="price">Rs. 30,000</span>
                <span class="days">10 Days </span>
                <h3><a href="#">company, one</a></h3>
                <p class="location"><span class="ion-ios-map"></span> company, one</p>
              </div>
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="project-wrap">
              <a href="#" class="img" style="background-image: url(images/destination-2.jpg);"></a>
              <div class="text p-4">
                <span class="price">Rs. 30,000</span>
                <span class="days">7 Days </span>
                <h3><a href="#">company, one</a></h3>
                <p class="location"><span class="ion-ios-map"></span> company, one</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section testimony-section bg-bottom" style="background-image: url(images/image_1.jpg);">
      <div class="container">
        <div class="row justify-content-center pb-4">
          <div class="col-md-7 text-center heading-section ftco-animate">
            <h2 class="mb-4">OUR TEAM</h2>
          </div>
        </div>
        <div class="row ftco-animate">
          <div class="col-md-12">
            <div class="carousel-testimony owl-carousel ftco-owl">
              <div class="item">
                <div class="testimony-wrap py-4">
                  <div class="text">
                    <p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,</p>
                    <div class="d-flex align-items-center">
                      <div class="user-img" style="background-image: url(images/person_1.jpg)"></div>
                      <div class="pl-3">
                        <p class="name">Roger Scott</p>
                        <span class="position">Marketing Manager</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap py-4">
                  <div class="text">
                    <p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,</p>
                    <div class="d-flex align-items-center">
                      <div class="user-img" style="background-image: url(images/person_2.jpg)"></div>
                      <div class="pl-3">
                        <p class="name">Roger Scott</p>
                        <span class="position">Marketing Manager</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap py-4">
                  <div class="text">
                    <p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,</p>
                    <div class="d-flex align-items-center">
                      <div class="user-img" style="background-image: url(images/person_3.jpg)"></div>
                      <div class="pl-3">
                        <p class="name">Roger Scott</p>
                        <span class="position">Marketing Manager</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap py-4">
                  <div class="text">
                    <p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,</p>
                    <div class="d-flex align-items-center">
                      <div class="user-img" style="background-image: url(images/person_1.jpg)"></div>
                      <div class="pl-3">
                        <p class="name">Roger Scott</p>
                        <span class="position">Marketing Manager</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap py-4">
                  <div class="text">
                    <p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,</p>
                    <div class="d-flex align-items-center">
                      <div class="user-img" style="background-image: url(images/person_2.jpg)"></div>
                      <div class="pl-3">
                        <p class="name">Roger Scott</p>
                        <span class="position">Marketing Manager</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>


    <section class="ftco-section">
      <div class="container">
        <div class="row justify-content-center pb-4">
          <div class="col-md-12 heading-section text-center ftco-animate">
            <h2 class="mb-4">Recent Activities</h2>
          </div>
        </div>
        <div class="row d-flex">
          <div class="col-md-4 d-flex ftco-animate">
            <div class="blog-entry justify-content-end">
              <a href="blog-single.html" class="block-20" style="background-image: url('images/image_1.jpg');">
                <div class="post-ov"></div>
              </a>
              <div class="text mt-3 float-right d-block">
                <div class="d-flex align-items-center mb-4 topp" style="border-radius: 0;width: 100%;">
                  <div class="one">
                    <span class="day">21</span>
                  </div>
                  <div class="two">
                    <span class="yr">2019</span>
                    <span class="mos">August</span>
                  </div>
                </div>
                <h3 class="heading"><a href="#">Lorem ipsum dolor sit amet, consectetur adipi</a></h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor.</p>
              </div>
            </div>
          </div>
          <div class="col-md-4 d-flex ftco-animate">
            <div class="blog-entry justify-content-end">
              <a href="blog-single.html" class="block-20" style="background-image: url('images/image_2.jpg');">
                <div class="post-ov"></div>
              </a>
              <div class="text mt-3 float-right d-block">
                <div class="d-flex align-items-center mb-4 topp" style="border-radius: 0;width: 100%;">
                  <div class="one">
                    <span class="day">21</span>
                  </div>
                  <div class="two">
                    <span class="yr">2019</span>
                    <span class="mos">August</span>
                  </div>
                </div>
                <h3 class="heading"><a href="#">Lorem ipsum dolor sit amet, consectetur adipi</a></h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor.</p>
              </div>
            </div>
          </div>
          <div class="col-md-4 d-flex ftco-animate">
            <div class="blog-entry">
              <a href="blog-single.html" class="block-20" style="background-image: url('images/image_3.jpg');">
                <div class="post-ov"></div>
              </a>
              <div class="text mt-3 float-right d-block">
                <div class="d-flex align-items-center mb-4 topp" style="border-radius: 0;width: 100%;">
                  <div class="one">
                    <span class="day">21</span>
                  </div>
                  <div class="two">
                    <span class="yr">2019</span>
                    <span class="mos">August</span>
                  </div>
                </div>
                <h3 class="heading"><a href="#">Lorem ipsum dolor sit amet, consectetur adipi</a></h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor.</p>
              </div>
              lorem
            </div>
          </div>
        </div>
      </div>
    </section>

    <footer class="ftco-footer bg-bottom" style="background-image: url(images/footer-bg.jpg);">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Vacation</h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
             <div class="ftco-footer-widget mb-2">
              <h2 class="ftco-heading-2">link</h2>
              <ul class="list-unstyled">
                <li><a href="#" class="py-2 d-block">link one</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Have a Questions?</h2>
              <div class="block-23 mb-3">
                <ul>
                  <li><span class="icon icon-map-marker"></span><span class="text">203 Fake St. Mountain View, San Francisco, California, USA</span></li>
                  <li><a href="#"><span class="icon icon-phone"></span><span class="text">+2 392 3929 210</span></a></li>
                  <li><a href="#"><span class="icon icon-envelope"></span><span class="text">info@yourdomain.com</span></a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>

      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>
<!-- ---------------------------------------------------------------------------------------- -->

<link href="dist/css/toastr8.css" rel="stylesheet" type="text/css">


<div class="container">

<script src="jquery.min.js"></script>
<script src="dist/js/toastr8.js"></script>
<script>
toastr8.info({
    message:'Toast message here', 
    title:"Title here",
    iconClass: "fa fa-info",
    imgURI: ["images/bg_2a.jpg"]
});
toastr8.error({
    message:'Toast message here', 
    title:"Title here",
    iconClass: "fa fa-info",
    imgURI: ["https://unsplash.it/120/120?image=20"]
});
toastr8.success({
    message:'Toast message here', 
    title:"Title here",
    iconClass: "fa fa-info",
    imgURI: ["https://unsplash.it/120/120?image=20"]
});
</script>
<!-- 
-------------------------------------------------------------------------------------------------------- -->
  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>